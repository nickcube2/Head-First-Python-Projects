from setuptools import setup

setup(
    
    name = 'vsearch',
    version='1.0',
    description='the head first python serach tool',
    author='author',
    author_email='awuninicholas@gmail.com',
    py_modules=['vsearch'],

)

